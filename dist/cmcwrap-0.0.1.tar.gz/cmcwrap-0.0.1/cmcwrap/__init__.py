from .core import Market

__repo__ = 'https://github.com/bitforce/wrapper-py-coinmarketcap'
__title__ = 'cmcwrap'
__author__ = 'Brandon Johnson'
__license__ = 'WTFPL'
__version__ = '0.0.1'
