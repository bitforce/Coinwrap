market = Market()
assert market.coin('bitcoin', limit=1)
assert market.stats()
