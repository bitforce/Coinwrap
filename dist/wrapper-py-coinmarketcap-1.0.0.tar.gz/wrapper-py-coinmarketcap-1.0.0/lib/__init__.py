__repo__ = 'https://github.com/bitforce/wrapper-py-coinmarketcap'
__title__ = 'wrapper-py-coinmarketcap'
__author__ = 'Brandon Johnson'
__license__ = 'WTFPL'
__version__ = '1.0.0'


from .core import Market
