from .core import Market

__repo__ = 'https://github.com/bitforce/wrapper-py-coinmarketcap'
__title__ = 'coinmarketcap_wrapper'
__author__ = 'Brandon Johnson'
__license__ = 'WTFPL'
__version__ = '1.0.0'
