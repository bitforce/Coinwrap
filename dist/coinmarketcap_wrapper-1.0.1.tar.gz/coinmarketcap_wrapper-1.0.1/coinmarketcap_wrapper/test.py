from core import Market

m = Market()
m.coin('bitcoin', limit=2)
