===========
core.py doc
===========

A.1:
    N/A

A.2:
    N/A
